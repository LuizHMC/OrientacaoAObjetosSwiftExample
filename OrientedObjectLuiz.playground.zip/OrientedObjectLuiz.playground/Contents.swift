
class MaquinarioPesado
{
    var rodas:Int = 0
    var tracao:Int = 0

    func drive()
    {
        print("Esse maquinario funciona")
    }
}

class Colheitadeira: MaquinarioPesado
{
    var temBraco = true

    override func drive()
    {
        print("Barulho claramente alto")
    }
}

class Trator: MaquinarioPesado
{
    var seats:Int = 0
    var potencia:Int = 1

    func mudaPotencia()
    {
        potencia += 1
    }
}

let colheitadeiraCafe = Colheitadeira()
colheitadeiraCafe.rodas = 8
colheitadeiraCafe.temBraco = false
colheitadeiraCafe.drive()

let tratorIsometrico = Trator()
tratorIsometrico.rodas = 3
tratorIsometrico.drive()

let tratorRodoviario = Trator()
tratorRodoviario.rodas = 8
tratorRodoviario.mudaPotencia()
tratorRodoviario.mudaPotencia()
print(tratorRodoviario.potencia)
